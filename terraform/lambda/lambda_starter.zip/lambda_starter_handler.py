import boto3
import json
import os

# Step Functions client
sfn = boto3.client("stepfunctions")

# Load Step Function ARN from environment variables
STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]

def lambda_handler(event, context):
    print("Received S3 event:", json.dumps(event))

    try:
        # Start Step Function execution
        response = sfn.start_execution(
            stateMachineArn=STATE_MACHINE_ARN,
            input=json.dumps(event)
        )

        print("Started Step Function execution:", response["executionArn"])

        return {
            "status": "step_function_started",
            "executionArn": response["executionArn"]
        }

    except Exception as e:
        print("Failed to start Step Function:", str(e))
        raise
