import json
import boto3
import os

sns = boto3.client("sns", endpoint_url="http://localhost:4566")

def lambda_handler(event, context):
    print("Event received:", json.dumps(event))

    filename = event["Records"][0]["s3"]["object"]["key"]

    sns.publish(
        TopicArn=os.environ["SNS_TOPIC_ARN"],
        Message=f"New file uploaded: {filename}"
    )

    return {"status": "ok"}
